# 文档导航

先读 [维护指南](MAINTENANCE.md)，了解后续改动应更新哪里、如何检查，以及如何让其他模型使用这套流程。

| 需求 | 主要位置 | 使用边界 |
|---|---|---|
| 构建与开发 | [DEVELOPMENT](DEVELOPMENT.md) | 运行相关命令后报告实际结果 |
| 系统总体结构 | [ARCHITECTURE_NEXT](ARCHITECTURE_NEXT.md) | 原图主要描述 JSONL；实时云端路径见下行 |
| 云端局面增量同步 | [当前行为](engine/cloud-position-sync.md) | 2026-10-04 已按工作区源码核对 |
| 重要决定及原因 | [决定索引](../.agents/notes/README.md) | 区分提案、已实施、否决与归档 |
| 本轮治理范围及核验 | [治理记录](maintenance/2026-10-04-adoption.md) | 列明保留项和未验证范围 |
| 发布前检查 | [RELEASE_CHECKLIST](RELEASE_CHECKLIST.md) | 检查清单不等于已发布证明 |
| 历史交接 | [HANDOVER_TO_CODEX](HANDOVER_TO_CODEX.md) | 2026-09-13 快照，不能当作当前状态 |
| 云端改动历史测试 | [2026-09-27 QA](qa/CLOUD_POSITION_LATENCY_20260927.md) | 保留当时原文，与本轮复核分开 |

`qa/`、`validation/`、`implementation/` 中的历史材料继续保留原位。`MIGRATION_PLAN.md` 和阶段总结用于追溯；其中完成状态与当前源码存在时间差，按需逐项核实。新增功能文档请在这里建立可找到的入口。
