# 人机对弈接入

首批范围：标准对局、当前节点续弈、HumanSL 风格陪练、隐藏提示、整回合悔棋、保存并复盘。

## 一致性边界

- 对局拥有独立 sessionId 与递增 generation；任一悔棋、停止、换局必须先失效在途请求。
- AI 返回必须同时匹配会话、generation、输入节点与执棋方；不得以“当前选中节点”接受旧结果。
- 续弈保存为原节点下分支，不覆盖原主线；悔棋只回退本次对局新增内容。
- 对局落子由当前局面 to_play 决定，禁止使用编辑工具的手工颜色。
- 双方连续 pass 进入终局确认；引擎估计不直接当作双方确认的最终结果。
- HumanSL 需要人类模型及实际人类策略选点，不能把普通 KataGo 搜索冠以段位陪练。
- 普通分析与对局搜索互斥；结束对局后允许恢复复盘。

## 迁移依据

Java NewGameDialog / NewAnaGameDialog / NewHumanSlGameDialog；HumanSlGameController；HumanSlAnalysisRunner。
涨棋网公开前端接口由独立调研任务记录；不依赖其私有服务完成本地功能。

## 涨棋网公开前端调研

证据：
- https://zhangqi.com.cn/fight
- https://zhangqi.com.cn/assets/FightView-wTbG-zHY.js
- https://zhangqi.com.cn/assets/fightService-C35CLmTO.js
- https://zhangqi.com.cn/assets/fightUtils-DQdNVLmb.js

普通陪练：POST /api/fights 建局；PUT /api/fights/{channel}/moves 提交完整局面并请求下一手；PUT /api/fights/{channel}/same 悔棋后同步；ownership/judge 请求终局/形势判断；result 保存结果；cache 恢复对局。仅阅读公开静态代码，未调用对局、计费或账户接口。

客户端检查返回 turnNumber 与当前手数，悔棋时取消等待并回到最近人类落子之前。普通陪练 aiSeconds 主要是显示节奏，不代表搜索预算。前端 rank 是服务端不透明档位（rank_1d 实际显示强5段），不能直接当作 HumanSL 参数。没有证据证明涨棋网服务端使用 HumanSL。

神狗挑战另用 /dog-socket.io 的 init/ask/same/ping/pause/continue/end 与 fightId/battleKey 标识；首批不迁移其计费和挑战体系。

## 本次实现与验证边界

已接入本地 KataGo 分析进程的独立、可复用对弈通道，生成私有配置（不改用户 GTP 配置）；支持新局/续弈、执黑白、规则/让子/贴目、时间与访问量上限、HumanSL 人类策略采样、整回合悔棋、pass/认输/连续 pass 结束，以及返回现有复盘工作区保存。续弈结果写在分支注释，不覆盖原棋谱主线结果。

标准对弈使用分析返回 order=0 的落点，不假称直接调用 GTP genmove。HumanSL 使用 humanPolicy 采样，缺失策略时明确报错，不退回强引擎冒充人类档位。

验证：前端 TypeScript 与生产构建通过；4 项选点测试通过；Rust 参数/配置/坐标测试；本机 KataGo 1.18.2，9路 B E5 后实际返回 C4 等合法候选，进程正常退出。

待验收：完整桌面交互（当前 CUA 连接连续超时，不能以构建代替视觉验证）；HumanSL 真实模型对局（本机未定位到模型）；远程/智子云对弈通道尚未接入，首版明确只用当前本地配置。终局数目暂仍需返回复盘判断，连续 pass 不自动伪造胜负。
